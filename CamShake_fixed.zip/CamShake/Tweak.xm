// CamShake - rung / rung xoay / zoom / đẩy máy (preview layer + khung hình camera web/app tự vẽ) + THAY ẢNH vào camera
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreImage/CoreImage.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import <ImageIO/ImageIO.h>
#import <objc/runtime.h>
#import <notify.h>

// Đường dẫn theo scheme: roothide -> jbroot(), rootless -> /var/jb/..., rootful -> giữ nguyên
#if defined(THEOS_PACKAGE_SCHEME_ROOTHIDE) && __has_include(<roothide.h>)
#import <roothide.h>
#define CS_ROOT(p) jbroot(p)
#elif __has_include(<rootless.h>)
#import <rootless.h>
#define CS_ROOT(p) ROOT_PATH_NS(p)
#else
#define CS_ROOT(p) (p)
#endif

// BẢN CHẨN ĐOÁN: vẽ ô vuông màu lên khung hình camera web (đỏ = tiến trình WebKit.GPU, xanh = WebContent)
// để biết tweak có được nạp + hook trong tiến trình WebKit hay không. Đặt 0 để tắt.
#define CS_WEB_MARK 0

typedef struct {
    BOOL enabled;   // bật hiệu ứng rung
    CGFloat shake;  // Độ rung      0..1  (tối đa 12 px)
    CGFloat roll;   // Rung xoay    0..1  (tối đa 3 độ)
    CGFloat zoom;   // Zoom         0..1  (tối đa +50%)
    CGFloat dolly;  // Đẩy máy      0..1  (tiến/lùi tối đa ~24%)
    BOOL useImage;  // dùng ảnh thay camera (theo từng app)
    int rot;        // xoay khung hình thật 0..3 (x90°)
    BOOL mirror;    // lật khung hình thật
} CSConfig;

static CSConfig cfg = {YES, 0.4, 0.3, 0.0, 0.3, YES, 0, NO};
static NSString *const kEn = @"CS_enabled", *const kSh = @"CS_shake", *const kRo = @"CS_roll",
                *const kZo = @"CS_zoom", *const kDo = @"CS_dolly",
                *const kUs = @"CS_useimg", *const kRt = @"CS_rot", *const kMi = @"CS_mirror";

static NSString *const kPrefsDomain = @"com.an.camshake";
#define CS_USER kCFPreferencesCurrentUser
#define CS_HOST kCFPreferencesAnyHost

// Trình duyệt: lưu xoay/lật vào prefs chung để process camera của WebKit (GPU) dùng lại
static void CSSaveWebPrefs(void);
static void CSLoadWebPrefs(void);

static void CSLoad(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    if ([d objectForKey:kEn]) cfg.enabled = [d boolForKey:kEn];
    if ([d objectForKey:kSh]) cfg.shake = [d floatForKey:kSh];
    if ([d objectForKey:kRo]) cfg.roll = [d floatForKey:kRo];
    if ([d objectForKey:kZo]) cfg.zoom = [d floatForKey:kZo];
    if ([d objectForKey:kDo]) cfg.dolly = [d floatForKey:kDo];
    if ([d objectForKey:kUs]) cfg.useImage = [d boolForKey:kUs];
    if ([d objectForKey:kRt]) cfg.rot = (int)([d integerForKey:kRt] & 3);
    if ([d objectForKey:kMi]) cfg.mirror = [d boolForKey:kMi];
}
static void CSSave(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setBool:cfg.enabled forKey:kEn];
    [d setFloat:cfg.shake forKey:kSh];
    [d setFloat:cfg.roll forKey:kRo];
    [d setFloat:cfg.zoom forKey:kZo];
    [d setFloat:cfg.dolly forKey:kDo];
    [d setBool:cfg.useImage forKey:kUs];
    [d setInteger:cfg.rot forKey:kRt];
    [d setBool:cfg.mirror forKey:kMi];
    CSSaveWebPrefs();
}

static void CSToast(NSString *text);

#pragma mark - Ảnh dùng chung giữa các app

// Ảnh được lưu ở: file (jbroot/var/mobile/... hoặc /var/mobile/...) + pasteboard có tên (dự phòng khi sandbox chặn file).
// Mọi app đều đọc bản mới nhất theo timestamp.
static UIImage *gImage;                 // ảnh đã chuẩn hoá (thẳng đứng, <= 2560px)
static volatile BOOL gHaveImage = NO;
static uint64_t gImageVersion = 0;
static double gLoadedT = 0;
static BOOL gFromShared = NO;
static NSInteger gPBCount = -1;
static double gPBTs = 0;
static BOOL gCaptureSeen = NO;
static volatile BOOL gHavePreview = NO;   // process này có AVCaptureVideoPreviewLayer -> hiệu ứng áp lên layer
static BOOL gHeadless = NO;   // process WebKit (không có UI) - chỉ hook, không hiện panel
static NSMutableArray<NSString *> *gLog;   // nhật ký lỗi gần nhất
static NSMutableSet<NSString *> *gLogOnce;
static NSUInteger gFramesReplaced = 0, gPhotosReplaced = 0;
static double gCaptureT = 0;
static BOOL gOverlayShown = NO;
static BOOL gDiagFile = NO, gDiagPrefs = NO;
static NSString *gProcKind = nil;   // @"gpu" / @"wc" cho process WebKit

static NSString *const kPBName = @"com.an.camshake.image";
static NSString *const kPBTs = @"com.an.camshake.ts";

static NSObject *CSLock(void) {
    static NSObject *o; static dispatch_once_t t;
    dispatch_once(&t, ^{ o = [NSObject new]; });
    return o;
}
// Ghi lỗi (mỗi loại 1 lần) + hiện toast cảnh báo
static void CSNote(NSString *key, NSString *msg, BOOL toast) {
    NSLog(@"[CamShake] %@", msg);
    BOOL fresh;
    @synchronized (CSLock()) {
        if (!gLogOnce) { gLogOnce = [NSMutableSet set]; gLog = [NSMutableArray array]; }
        fresh = ![gLogOnce containsObject:key];
        if (fresh) {
            [gLogOnce addObject:key];
            [gLog addObject:msg];
            if (gLog.count > 4) [gLog removeObjectAtIndex:0];
        }
    }
    if (fresh && toast)
        dispatch_async(dispatch_get_main_queue(), ^{ CSToast([@"⚠️ " stringByAppendingString:msg]); });
}
static inline BOOL CSActive(void) { return cfg.useImage && gHaveImage; }
static inline BOOL CSFxWanted(void) {
    if (!cfg.enabled) return NO;
    if (cfg.shake + cfg.roll + cfg.zoom + cfg.dolly < 0.001) return NO;
    return gHeadless || !gHavePreview;   // web / app không có preview layer: áp thẳng lên khung hình
}

static NSArray<NSString *> *CSDirs(void) {
    return @[CS_ROOT(@"/var/mobile/Library/CamShake"), @"/var/mobile/Library/CamShake"];
}

static BOOL CSWritePrefs(NSData *jpeg, double t) {
    CFStringRef dom = (__bridge CFStringRef)kPrefsDomain;
    CFPreferencesSetValue(CFSTR("img"), (__bridge CFPropertyListRef)jpeg, dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("ts"), (__bridge CFPropertyListRef)@(t), dom, CS_USER, CS_HOST);
    return CFPreferencesSynchronize(dom, CS_USER, CS_HOST);
}
static NSData *CSPrefsData(void) {
    CFPropertyListRef v = CFPreferencesCopyValue(CFSTR("img"), (__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    if (!v) return nil;
    NSData *d = nil;
    if (CFGetTypeID(v) == CFDataGetTypeID()) d = [(__bridge NSData *)v copy];
    CFRelease(v);
    return d;
}
static double CSPrefsTs(void) {
    CFPropertyListRef v = CFPreferencesCopyValue(CFSTR("ts"), (__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    double t = 0;
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &t);
        CFRelease(v);
    }
    return t;
}
static void CSSaveWebPrefs(void) {
    NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
    NSArray *browsers = @[@"com.apple.mobilesafari", @"com.google.chrome.ios", @"org.mozilla.ios.Firefox",
                          @"com.brave.ios.browser", @"com.microsoft.msedge", @"com.opera.OperaTouch",
                          @"com.duckduckgo.mobile.ios"];
    if (![browsers containsObject:bid]) return;
    CFStringRef dom = (__bridge CFStringRef)kPrefsDomain;
    CFPreferencesSetValue(CFSTR("web_rot"), (__bridge CFPropertyListRef)@(cfg.rot), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_mirror"), (__bridge CFPropertyListRef)@(cfg.mirror ? 1 : 0), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_use"), (__bridge CFPropertyListRef)@(cfg.useImage ? 1 : 0), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_en"), (__bridge CFPropertyListRef)@(cfg.enabled ? 1 : 0), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_shake"), (__bridge CFPropertyListRef)@((int)lround(cfg.shake * 1000)), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_roll"), (__bridge CFPropertyListRef)@((int)lround(cfg.roll * 1000)), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_zoom"), (__bridge CFPropertyListRef)@((int)lround(cfg.zoom * 1000)), dom, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("web_dolly"), (__bridge CFPropertyListRef)@((int)lround(cfg.dolly * 1000)), dom, CS_USER, CS_HOST);
    CFPreferencesSynchronize(dom, CS_USER, CS_HOST);
}
static int CSPrefsInt(CFStringRef key, int def) {
    CFPropertyListRef v = CFPreferencesCopyValue(key, (__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    int r = def;
    if (v) {
        if (CFGetTypeID(v) == CFNumberGetTypeID()) CFNumberGetValue((CFNumberRef)v, kCFNumberIntType, &r);
        CFRelease(v);
    }
    return r;
}
static void CSLoadWebPrefs(void) {
    cfg.rot = CSPrefsInt(CFSTR("web_rot"), cfg.rot) & 3;
    cfg.mirror = CSPrefsInt(CFSTR("web_mirror"), cfg.mirror ? 1 : 0) != 0;
    cfg.useImage = CSPrefsInt(CFSTR("web_use"), cfg.useImage ? 1 : 0) != 0;
    cfg.enabled = CSPrefsInt(CFSTR("web_en"), cfg.enabled ? 1 : 0) != 0;
    cfg.shake = CSPrefsInt(CFSTR("web_shake"), (int)lround(cfg.shake * 1000)) / 1000.0;
    cfg.roll  = CSPrefsInt(CFSTR("web_roll"),  (int)lround(cfg.roll  * 1000)) / 1000.0;
    cfg.zoom  = CSPrefsInt(CFSTR("web_zoom"),  (int)lround(cfg.zoom  * 1000)) / 1000.0;
    cfg.dolly = CSPrefsInt(CFSTR("web_dolly"), (int)lround(cfg.dolly * 1000)) / 1000.0;
}

static void CSApplyImage(UIImage *img, double t, BOOL fromShared) {
    @synchronized (CSLock()) {
        gImage = img;
        gHaveImage = (img != nil);
        gImageVersion++;
        gLoadedT = t;
        gFromShared = fromShared;
    }
}

static BOOL CSWriteShared(NSData *jpeg, double t) {
    BOOL ok = NO;
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *dir in CSDirs()) {
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES
                       attributes:@{NSFilePosixPermissions: @0777} error:nil];
        NSString *p = [dir stringByAppendingPathComponent:@"image.jpg"];
        if ([jpeg writeToFile:p atomically:YES]) {
            [fm setAttributes:@{NSFileModificationDate: [NSDate dateWithTimeIntervalSince1970:t],
                                NSFilePosixPermissions: @0666} ofItemAtPath:p error:nil];
            ok = YES;
        }
    }
    if (!ok) CSNote(@"file", @"Không ghi được file ảnh (sandbox) - dùng pasteboard dự phòng", NO);
    UIPasteboard *pb = [UIPasteboard pasteboardWithName:kPBName create:YES];
    if (pb) {
        pb.items = @[@{ @"public.jpeg": jpeg, kPBTs: [NSString stringWithFormat:@"%.3f", t] }];
        gPBCount = pb.changeCount;
        gPBTs = t;
        ok = YES;
    }
    return ok;
}

static void CSSetImage(UIImage *src) {
    if (!src) return;
    CGFloat pw = src.size.width * src.scale, ph = src.size.height * src.scale;
    if (pw < 1 || ph < 1) return;
    CGFloat f = MIN(1.0, 2560.0 / MAX(pw, ph));
    CGSize ts = CGSizeMake(MAX(1, round(pw * f)), MAX(1, round(ph * f)));
    UIGraphicsImageRendererFormat *fmt = [UIGraphicsImageRendererFormat defaultFormat];
    fmt.scale = 1; fmt.opaque = YES;
    fmt.preferredRange = UIGraphicsImageRendererFormatRangeStandard;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:ts format:fmt];
    UIImage *norm = [r imageWithActions:^(UIGraphicsImageRendererContext *c) {
        [src drawInRect:CGRectMake(0, 0, ts.width, ts.height)]; // drawInRect tự áp dụng orientation
    }];
    NSData *jpeg = UIImageJPEGRepresentation(norm, 0.92);
    if (!jpeg) return;
    double t = floor([[NSDate date] timeIntervalSince1970] * 1000.0) / 1000.0;
    BOOL wrote = CSWriteShared(jpeg, t);
    {   // bản nhỏ (<=1280px) cho kênh prefs - process WebKit đọc qua cfprefsd
        CGFloat f2 = MIN(1.0, 1280.0 / MAX(ts.width, ts.height));
        CGSize s2 = CGSizeMake(MAX(1, round(ts.width * f2)), MAX(1, round(ts.height * f2)));
        UIGraphicsImageRenderer *r2 = [[UIGraphicsImageRenderer alloc] initWithSize:s2 format:fmt];
        UIImage *small = [r2 imageWithActions:^(UIGraphicsImageRendererContext *c) {
            [norm drawInRect:CGRectMake(0, 0, s2.width, s2.height)];
        }];
        NSData *sj = UIImageJPEGRepresentation(small, 0.85);
        if (sj && CSWritePrefs(sj, t)) wrote = YES;
    }
    if (!wrote) CSNote(@"write", @"Không lưu được ảnh dùng chung - chỉ app này thấy ảnh", YES);
    CSApplyImage(norm, t, wrote);
}

static void CSClearImage(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *dir in CSDirs())
        [fm removeItemAtPath:[dir stringByAppendingPathComponent:@"image.jpg"] error:nil];
    UIPasteboard *pb = [UIPasteboard pasteboardWithName:kPBName create:NO];
    if (pb) { pb.items = @[]; gPBCount = pb.changeCount; }
    CFPreferencesSetValue(CFSTR("img"), NULL, (__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    CFPreferencesSetValue(CFSTR("ts"), NULL, (__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    CFPreferencesSynchronize((__bridge CFStringRef)kPrefsDomain, CS_USER, CS_HOST);
    gPBTs = 0;
    CSApplyImage(nil, 0, NO);
}

// Gọi ~1 lần/giây: đồng bộ ảnh mới từ app khác (file / pasteboard / prefs)
static void CSRefreshImage(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    CFPreferencesAppSynchronize((__bridge CFStringRef)kPrefsDomain);
    if (gHeadless) CSLoadWebPrefs();

    double fileT = 0; NSString *filePath = nil;
    for (NSString *dir in CSDirs()) {
        NSString *p = [dir stringByAppendingPathComponent:@"image.jpg"];
        NSDate *md = [[fm attributesOfItemAtPath:p error:nil] fileModificationDate];
        double t = md ? [md timeIntervalSince1970] : 0;
        if (t > fileT) { fileT = t; filePath = p; }
    }
    gDiagFile = fileT > 0;

    double pbT = 0;
    UIPasteboard *pb = gHeadless ? nil : [UIPasteboard pasteboardWithName:kPBName create:NO];
    if (pb) {
        NSInteger cc = pb.changeCount;
        if (cc != gPBCount) {
            gPBCount = cc;
            id v = [pb valueForPasteboardType:kPBTs];
            NSString *s = nil;
            if ([v isKindOfClass:[NSData class]]) s = [[NSString alloc] initWithData:v encoding:NSUTF8StringEncoding];
            else if ([v isKindOfClass:[NSString class]]) s = v;
            gPBTs = s ? s.doubleValue : 0;
        }
        pbT = gPBTs;
    }
    double prefsT = CSPrefsTs();
    gDiagPrefs = prefsT > 0;

    double newest = MAX(MAX(fileT, pbT), prefsT);
    if (newest <= 0) {
        if (gHaveImage && gFromShared) CSApplyImage(nil, 0, NO); // ảnh đã bị xoá từ app khác
        return;
    }
    if (newest <= gLoadedT + 0.0015) return;

    NSData *data = nil;
    if (fileT > 0 && fileT >= newest - 0.0015 && filePath) data = [NSData dataWithContentsOfFile:filePath];
    if (!data && pb && pbT > 0 && pbT >= newest - 0.0015) data = [pb dataForPasteboardType:@"public.jpeg"];
    if (!data && prefsT > 0) data = CSPrefsData();
    if (!data && filePath) data = [NSData dataWithContentsOfFile:filePath];
    UIImage *img = data ? [UIImage imageWithData:data] : nil;
    if (img && img.CGImage) CSApplyImage(img, newest, YES);
}

#pragma mark - Vẽ ảnh vào khung hình / pixel buffer

static CGColorSpaceRef CSRGB(void) {
    static CGColorSpaceRef cs; static dispatch_once_t t;
    dispatch_once(&t, ^{ cs = CGColorSpaceCreateDeviceRGB(); });
    return cs;
}
static CIContext *CSCIContext(void) {
    static CIContext *c; static dispatch_once_t t;
    dispatch_once(&t, ^{ c = [CIContext contextWithOptions:nil]; });
    return c;
}

// Vẽ ảnh (aspect-fill) vào bitmap W x H. q = số lần xoay 90° ngược chiều kim đồng hồ.
static CGImageRef CSCreateRendered(size_t W, size_t H, int q, BOOL mirror) {
    CGImageRef img = NULL;
    @synchronized (CSLock()) {
        img = gImage.CGImage;
        if (img) CGImageRetain(img);
    }
    if (!img || !W || !H) { if (img) CGImageRelease(img); return NULL; }
    CGContextRef ctx = CGBitmapContextCreate(NULL, W, H, 8, 0, CSRGB(),
                                             (CGBitmapInfo)(kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst));
    if (!ctx) { CGImageRelease(img); return NULL; }
    CGContextSetInterpolationQuality(ctx, kCGInterpolationHigh);
    CGContextSetRGBFillColor(ctx, 0, 0, 0, 1);
    CGContextFillRect(ctx, CGRectMake(0, 0, W, H));
    CGContextTranslateCTM(ctx, W / 2.0, H / 2.0);
    CGContextRotateCTM(ctx, (q & 3) * M_PI_2);
    if (mirror) CGContextScaleCTM(ctx, -1, 1);
    CGFloat iw = CGImageGetWidth(img), ih = CGImageGetHeight(img);
    CGFloat bw = (q & 1) ? H : W, bh = (q & 1) ? W : H;
    CGFloat s = MAX(bw / iw, bh / ih);
    CGContextDrawImage(ctx, CGRectMake(-iw * s / 2, -ih * s / 2, iw * s, ih * s), img);
    CGImageRef out = CGBitmapContextCreateImage(ctx);
    CGContextRelease(ctx);
    CGImageRelease(img);
    return out;
}

static NSData *CSEncodeJPEG(CGImageRef cg) {
    NSMutableData *out = [NSMutableData data];
    CGImageDestinationRef d = CGImageDestinationCreateWithData((__bridge CFMutableDataRef)out, CFSTR("public.jpeg"), 1, NULL);
    if (!d) return nil;
    NSDictionary *opts = @{ (__bridge id)kCGImageDestinationLossyCompressionQuality: @0.92 };
    CGImageDestinationAddImage(d, cg, (__bridge CFDictionaryRef)opts);
    BOOL ok = CGImageDestinationFinalize(d);
    CFRelease(d);
    return ok ? out : nil;
}

// Thay dữ liệu ảnh chụp (JPEG/HEIC) bằng ảnh của mình, giữ nguyên kích thước hiển thị
static NSData *CSReplaceJPEG(NSData *orig) {
    if (!orig.length || !CSActive()) return orig;
    CGImageSourceRef src = CGImageSourceCreateWithData((__bridge CFDataRef)orig, NULL);
    if (!src) return orig;
    NSDictionary *p = CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(src, 0, NULL));
    CFRelease(src);
    size_t w = [p[(__bridge NSString *)kCGImagePropertyPixelWidth] unsignedLongValue];
    size_t h = [p[(__bridge NSString *)kCGImagePropertyPixelHeight] unsignedLongValue];
    int o = [p[(__bridge NSString *)kCGImagePropertyOrientation] intValue];
    if (!w || !h) return orig;
    if (o >= 5 && o <= 8) { size_t t = w; w = h; h = t; }
    CGFloat f = MIN(1.0, 4032.0 / (CGFloat)MAX(w, h));
    w = MAX((size_t)1, (size_t)llround(w * f));
    h = MAX((size_t)1, (size_t)llround(h * f));
    CGImageRef cg = CSCreateRendered(w, h, 0, cfg.mirror);
    if (!cg) { CSNote(@"jpeg", @"Không vẽ được ảnh chụp thay thế", YES); return orig; }
    NSData *n = CSEncodeJPEG(cg);
    CGImageRelease(cg);
    if (!n) CSNote(@"jpeg2", @"Không mã hoá được JPEG cho ảnh chụp", YES);
    return n ?: orig;
}

// Pixel buffer mẫu (đã vẽ ảnh) cùng kích thước + định dạng với buffer camera. Trả về +1 retain.
static NSString *CSFourCC(OSType f) {
    char c[5] = {(char)(f >> 24), (char)(f >> 16), (char)(f >> 8), (char)f, 0};
    for (int i = 0; i < 4; i++) if (c[i] < 32 || c[i] > 126) return [NSString stringWithFormat:@"0x%08x", (unsigned)f];
    return [NSString stringWithUTF8String:c];
}
static CVPixelBufferRef gTpl; static size_t gTW, gTH; static OSType gTF; static int gTQ; static BOOL gTM; static uint64_t gTV;

static CVPixelBufferRef CSTemplate(CVPixelBufferRef pb, int q, BOOL mir) {
    size_t W = CVPixelBufferGetWidth(pb), H = CVPixelBufferGetHeight(pb);
    OSType f = CVPixelBufferGetPixelFormatType(pb);
    @synchronized (CSLock()) {
        if (gTpl && gTW == W && gTH == H && gTF == f && gTQ == q && gTM == mir && gTV == gImageVersion)
            return (CVPixelBufferRef)CFRetain(gTpl);
        CGImageRef cg = CSCreateRendered(W, H, q, mir);
        if (!cg) { CSNote(@"tplcg", [NSString stringWithFormat:@"Không vẽ được ảnh %zux%zu", W, H], YES); return NULL; }
        CVPixelBufferRef t = NULL;
        NSDictionary *attrs = @{ (__bridge id)kCVPixelBufferIOSurfacePropertiesKey: @{} };
        CVReturn r = CVPixelBufferCreate(kCFAllocatorDefault, W, H, f, (__bridge CFDictionaryRef)attrs, &t);
        if (r != kCVReturnSuccess || !t) {
            CGImageRelease(cg);
            CSNote(@"tplpb", [NSString stringWithFormat:@"Không tạo được khung hình định dạng %@ (%zux%zu)", CSFourCC(f), W, H], YES);
            return NULL;
        }
        CIImage *ci = [CIImage imageWithCGImage:cg];
        [CSCIContext() render:ci toCVPixelBuffer:t bounds:CGRectMake(0, 0, W, H) colorSpace:CSRGB()];
        CGImageRelease(cg);
        if (gTpl) CFRelease(gTpl);
        gTpl = t; gTW = W; gTH = H; gTF = f; gTQ = q; gTM = mir; gTV = gImageVersion;
        return (CVPixelBufferRef)CFRetain(gTpl);
    }
}

static void CSCopyRows(void *dst, size_t dbpr, const void *src, size_t sbpr, size_t rows) {
    size_t n = MIN(dbpr, sbpr);
    for (size_t y = 0; y < rows; y++)
        memcpy((uint8_t *)dst + y * dbpr, (const uint8_t *)src + y * sbpr, n);
}
static void CSCopyPB(CVPixelBufferRef src, CVPixelBufferRef dst) {
    CVPixelBufferLockBaseAddress(src, kCVPixelBufferLock_ReadOnly);
    CVPixelBufferLockBaseAddress(dst, 0);
    size_t planes = CVPixelBufferGetPlaneCount(src);
    if (planes == 0) {
        void *d = CVPixelBufferGetBaseAddress(dst); void *s = CVPixelBufferGetBaseAddress(src);
        if (d && s) CSCopyRows(d, CVPixelBufferGetBytesPerRow(dst), s, CVPixelBufferGetBytesPerRow(src),
                               MIN(CVPixelBufferGetHeight(dst), CVPixelBufferGetHeight(src)));
    } else if (planes == CVPixelBufferGetPlaneCount(dst)) {
        for (size_t p = 0; p < planes; p++) {
            void *d = CVPixelBufferGetBaseAddressOfPlane(dst, p); void *s = CVPixelBufferGetBaseAddressOfPlane(src, p);
            if (d && s) CSCopyRows(d, CVPixelBufferGetBytesPerRowOfPlane(dst, p), s, CVPixelBufferGetBytesPerRowOfPlane(src, p),
                                   MIN(CVPixelBufferGetHeightOfPlane(dst, p), CVPixelBufferGetHeightOfPlane(src, p)));
        }
    }
    CVPixelBufferUnlockBaseAddress(dst, 0);
    CVPixelBufferUnlockBaseAddress(src, kCVPixelBufferLock_ReadOnly);
}

#pragma mark - Overlay trên preview layer

@interface CSOverlay : CALayer
@property (nonatomic) uint64_t ver;
@end
@implementation CSOverlay
@end

static char kOvKey;
static void CSSyncOverlay(CALayer *layer) {
    CSOverlay *ov = objc_getAssociatedObject(layer, &kOvKey);
    if (!CSActive()) { if (ov && !ov.hidden) ov.hidden = YES; return; }
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    if (!ov) {
        ov = [CSOverlay layer];
        ov.masksToBounds = YES;
        ov.contentsGravity = kCAGravityResizeAspectFill;
        ov.backgroundColor = UIColor.blackColor.CGColor;
        ov.zPosition = 9999;
        objc_setAssociatedObject(layer, &kOvKey, ov, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (ov.superlayer != layer) [layer addSublayer:ov];
    ov.hidden = NO;
    if (!CGRectEqualToRect(ov.frame, layer.bounds)) ov.frame = layer.bounds;
    uint64_t v = gImageVersion;
    if (ov.ver != v || !ov.contents) {
        UIImage *im = gImage;
        if (im.CGImage) { ov.contents = (__bridge id)im.CGImage; ov.ver = v; }
    }
    [CATransaction commit];
}

#pragma mark - Trạng thái process WebKit (Darwin notify)

// process GPU/WebContent báo trạng thái qua notify state; panel trong Safari đọc lại để hiển thị
static int gStTok = -1;
static void CSPublishStatus(void) {
    if (!gHeadless || !gProcKind) return;
    if (gStTok < 0) {
        NSString *name = [@"com.an.camshake.st." stringByAppendingString:gProcKind];
        if (notify_register_check(name.UTF8String, &gStTok) != NOTIFY_STATUS_OK) { gStTok = -1; return; }
    }
    BOOL err = NO;
    @synchronized (CSLock()) { err = gLog.count > 0; }
    uint64_t v = 1ULL | (gCaptureSeen ? 2ULL : 0) | (gHaveImage ? 4ULL : 0) | (err ? 8ULL : 0)
               | (gDiagFile ? 16ULL : 0) | (gDiagPrefs ? 32ULL : 0)
               | ((uint64_t)(uint32_t)gFramesReplaced << 32);
    notify_set_state(gStTok, v);
}
static NSString *CSProcStatusText(const char *name, NSString *label, BOOL always) {
    static NSMutableDictionary *toks;
    if (!toks) toks = [NSMutableDictionary dictionary];
    NSString *key = [NSString stringWithUTF8String:name];
    int tok = [toks[key] intValue];
    if (!toks[key]) {
        tok = -1;
        if (notify_register_check(name, &tok) != NOTIFY_STATUS_OK) tok = -1;
        toks[key] = @(tok);
    }
    uint64_t v = 0;
    if (tok >= 0) notify_get_state(tok, &v);
    if (!v) return always ? [NSString stringWithFormat:@"%@: chưa phản hồi (mở trang web có camera rồi xem lại; nếu vẫn vậy = chưa nạp vào WebKit)", label] : nil;
    return [NSString stringWithFormat:@"%@: nạp ✓ • camera %@ • ảnh %@ (file %@ prefs %@) • thay %u khung%@",
            label, (v & 2) ? @"✓" : @"✗", (v & 4) ? @"✓" : @"✗", (v & 16) ? @"✓" : @"✗", (v & 32) ? @"✓" : @"✗",
            (unsigned)(v >> 32), (v & 8) ? @" • có lỗi" : @""];
}

#pragma mark - UI helpers

static UIWindow *CSKeyWindow(void) {
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes) {
        if ([sc isKindOfClass:[UIWindowScene class]]) {
            for (UIWindow *w in ((UIWindowScene *)sc).windows) if (w.isKeyWindow) return w;
        }
    }
    // Không có key window (nhiều scene / đang hiện alert...) -> lấy cửa sổ hiển thị đầu tiên
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes) {
        if ([sc isKindOfClass:[UIWindowScene class]]) {
            for (UIWindow *w in ((UIWindowScene *)sc).windows) if (!w.hidden && w.windowLevel <= UIWindowLevelNormal) return w;
        }
    }
    return nil;
}
static UIViewController *CSTopVC(void) {
    UIViewController *vc = CSKeyWindow().rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    return vc;
}

@interface CSUI : NSObject <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UILabel *info, *status;
@property (nonatomic, strong) UIButton *rotBtn, *mirBtn;
@property (nonatomic) uint64_t uiVer;
+ (instancetype)shared;
- (void)install;
- (void)setActive:(BOOL)active;
- (void)syncInfo;
- (void)syncIfNeeded;
- (void)syncStatus;
- (void)attachGesture:(UIWindow *)w;
@end

#pragma mark - Driver

@interface CSDriver : NSObject
@property (nonatomic, strong) NSHashTable *layers;
@property (nonatomic, strong) CADisplayLink *link;
@property (nonatomic, strong) NSTimer *scanTimer;
@property (nonatomic) double lastRefresh;
@property (nonatomic, strong) NSTimer *hTimer;
+ (instancetype)shared;
- (void)startHeadless;
- (void)add:(CALayer *)layer;
- (void)markCapture;
- (void)startScanning;
@end

static void CSVisit(CALayer *l, int depth, Class pv, NSMutableArray *out) {
    if (depth > 60) return;
    if ([l isKindOfClass:pv]) [out addObject:l];
    for (CALayer *s in [l.sublayers copy]) CSVisit(s, depth + 1, pv, out);
}

@implementation CSDriver
+ (instancetype)shared {
    static CSDriver *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [CSDriver new]; s.layers = [NSHashTable weakObjectsHashTable]; });
    return s;
}
- (void)startHeadless {
    if (self.hTimer) return;
    self.hTimer = [NSTimer timerWithTimeInterval:1.0 repeats:YES block:^(NSTimer *t) {
        CSRefreshImage();
        CSPublishStatus();
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.hTimer forMode:NSRunLoopCommonModes];
    CSRefreshImage();
    CSPublishStatus();
}
- (void)ensureLink {
    if (gHeadless) { [self startHeadless]; return; }
    if (self.link) return;
    self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
    [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}
- (void)add:(CALayer *)layer {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.layers addObject:layer];
        gHavePreview = YES;
        [[CSUI shared] install];
        [self ensureLink];
    });
}
// App có AVCaptureVideoDataOutput (video call, livestream, quét...) dù không có preview layer
- (void)markCapture {
    dispatch_async(dispatch_get_main_queue(), ^{
        gCaptureSeen = YES;
        if (gCaptureT == 0) gCaptureT = CACurrentMediaTime();
        CSRefreshImage();
        if (cfg.useImage && !gHaveImage && !CSFxWanted())
            CSNote(@"noimg", @"Camera đang chạy nhưng chưa chọn ảnh: bấm 📳 > Chọn ảnh", YES);
        [[CSUI shared] install];
        [self ensureLink];
    });
}
- (void)startScanning {
    if (self.scanTimer) return;
    self.scanTimer = [NSTimer timerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *t) { [self scan]; }];
    [[NSRunLoop mainRunLoop] addTimer:self.scanTimer forMode:NSRunLoopCommonModes];
}
- (void)scan {
    [[CSUI shared] install];
    [[CSUI shared] setActive:YES];
    {   // Safari không có preview layer nên tick() không chạy: làm mới trạng thái ở đây
        CSUI *ui = [CSUI shared];
        if (ui.panel && !ui.panel.hidden) { [ui syncStatus]; [ui syncIfNeeded]; }
    }
    Class pv = NSClassFromString(@"AVCaptureVideoPreviewLayer");
    if (!pv) return;
    NSMutableArray *found = [NSMutableArray array];
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes) {
        if (![sc isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *w in ((UIWindowScene *)sc).windows) { CSVisit(w.layer, 0, pv, found); [[CSUI shared] attachGesture:w]; }
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *w in UIApplication.sharedApplication.windows) { CSVisit(w.layer, 0, pv, found); [[CSUI shared] attachGesture:w]; }
#pragma clang diagnostic pop
    for (CALayer *l in found) if (![self.layers containsObject:l]) [self add:l];
}
- (void)tick:(CADisplayLink *)l {
    double t = CACurrentMediaTime();
    BOOL any = gCaptureSeen, havePV = NO;
    if (t - self.lastRefresh > 1.0) {
        self.lastRefresh = t;
        CSRefreshImage();
        if (gCaptureT > 0 && t - gCaptureT > 6 && CSActive() && !gOverlayShown && gFramesReplaced == 0)
            CSNote(@"noeffect", @"Camera chạy nhưng chưa thay được khung/preview nào (app dùng cách khác?)", YES);
        [[CSUI shared] syncStatus];
    }
    [[CSUI shared] syncIfNeeded];
    for (CALayer *layer in self.layers.allObjects) {
        if (!layer.superlayer) continue;
        any = YES; havePV = YES;
        CSSyncOverlay(layer);
        if (CSActive()) gOverlayShown = YES;
        if (!cfg.enabled) {
            if (!CATransform3DIsIdentity(layer.transform)) layer.transform = CATransform3DIdentity;
            continue;
        }
        layer.superlayer.masksToBounds = YES;
        CGFloat minDim = MIN(layer.bounds.size.width, layer.bounds.size.height);
        if (minDim <= 0) continue;

        CGFloat sMax = 12.0 * cfg.shake;
        CGFloat dx = sMax * (sin(t * 7.3) + 0.5 * sin(t * 13.1 + 1.7)) / 1.5;
        CGFloat dy = sMax * (sin(t * 6.1 + 0.9) + 0.5 * sin(t * 11.3 + 2.4)) / 1.5;
        CGFloat rollRad = (3.0 * cfg.roll) * M_PI / 180.0 * (sin(t * 5.1) + 0.4 * sin(t * 11.7 + 0.6)) / 1.4;

        // Phóng nhẹ để không lộ viền khi rung / xoay
        CGFloat margin = 1.0 + 2.0 * sMax / minDim + fabs(3.0 * cfg.roll * M_PI / 180.0) * 1.2;
        CGFloat zoom = 1.0 + 0.5 * cfg.zoom;
        CGFloat push = 1.0 + 0.24 * cfg.dolly * (0.5 + 0.5 * sin(t * 2.5)); // chỉ tiến vào
        CGFloat scale = margin * zoom * push;

        CGAffineTransform tr = CGAffineTransformMakeTranslation(dx, dy);
        tr = CGAffineTransformRotate(tr, rollRad);
        tr = CGAffineTransformScale(tr, scale, scale);
        layer.transform = CATransform3DMakeAffineTransform(tr);
    }
    gHavePreview = havePV;
    [[CSUI shared] setActive:any];
}
@end

#pragma mark - Panel điều khiển

@implementation CSUI
+ (instancetype)shared { static CSUI *s; static dispatch_once_t o; dispatch_once(&o, ^{ s = [CSUI new]; }); return s; }

static UILabel *CSLabel(NSString *text, CGRect f, CGFloat size) {
    UILabel *l = [[UILabel alloc] initWithFrame:f];
    l.text = text; l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:size];
    return l;
}

- (void)install {
    if (self.button || gHeadless) return;
    UIWindow *w = CSKeyWindow();
    if (!w) {
        static int tries = 0;
        if (++tries == 20) CSNote(@"nowin", @"Không tìm thấy cửa sổ để hiện nút 📳", NO);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ [self install]; });
        return;
    }

    self.button = [UIButton buttonWithType:UIButtonTypeSystem];
    self.button.frame = CGRectMake(w.bounds.size.width - 54, 100, 44, 44);
    self.button.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
    self.button.layer.cornerRadius = 22;
    [self.button setTitle:@"📳" forState:UIControlStateNormal];
    [self.button addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
    {   // kéo để di chuyển nút; nhớ vị trí theo từng app
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        if ([d objectForKey:@"CS_bx"]) {
            CGFloat bx = [d floatForKey:@"CS_bx"], by = [d floatForKey:@"CS_by"];
            self.button.center = CGPointMake(MIN(MAX(bx, 22), w.bounds.size.width - 22), MIN(MAX(by, 22), w.bounds.size.height - 22));
        }
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragged:)];
        [self.button addGestureRecognizer:pan];
    }
    [w addSubview:self.button];

    CGFloat pw = w.bounds.size.width - 32;
    self.panel = [[UIView alloc] initWithFrame:CGRectMake(16, 110, pw, 500)];
    self.panel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.82];
    self.panel.layer.cornerRadius = 14;
    self.panel.hidden = YES;
    [w addSubview:self.panel];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 12, 160, 30)];
    title.text = @"CamShake"; title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:17];
    [self.panel addSubview:title];

    UISwitch *sw = [UISwitch new];
    sw.center = CGPointMake(pw - 16 - sw.bounds.size.width / 2, 27);
    sw.on = cfg.enabled;
    [sw addTarget:self action:@selector(swChanged:) forControlEvents:UIControlEventValueChanged];
    [self.panel addSubview:sw];

    // --- Ảnh thay camera ---
    [self.panel addSubview:CSLabel(@"Dùng ảnh thay camera", CGRectMake(16, 54, pw - 100, 24), 15)];
    UISwitch *us = [UISwitch new];
    us.center = CGPointMake(pw - 16 - us.bounds.size.width / 2, 66);
    us.on = cfg.useImage;
    [us addTarget:self action:@selector(useChanged:) forControlEvents:UIControlEventValueChanged];
    [self.panel addSubview:us];

    self.info = CSLabel(@"", CGRectMake(16, 84, pw - 32, 18), 12);
    self.info.textColor = [UIColor colorWithWhite:0.75 alpha:1];
    [self.panel addSubview:self.info];

    NSArray *bt = @[@"Chọn ảnh", @"Xoá", @"", @""];
    CGFloat bw = (pw - 32 - 3 * 8) / 4.0;
    for (int i = 0; i < 4; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        b.frame = CGRectMake(16 + i * (bw + 8), 108, bw, 32);
        b.tag = i;
        b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.18];
        b.layer.cornerRadius = 8;
        [b setTitle:bt[i] forState:UIControlStateNormal];
        [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        b.titleLabel.font = [UIFont boldSystemFontOfSize:12];
        b.titleLabel.adjustsFontSizeToFitWidth = YES;
        b.titleLabel.minimumScaleFactor = 0.6;
        [b addTarget:self action:@selector(btnTapped:) forControlEvents:UIControlEventTouchUpInside];
        [self.panel addSubview:b];
        if (i == 2) self.rotBtn = b;
        if (i == 3) self.mirBtn = b;
    }
    [self syncButtons];
    [self syncInfo];

    // --- Hiệu ứng rung ---
    NSArray *names = @[@"Độ rung", @"Rung xoay", @"Zoom", @"Đẩy máy"];
    CGFloat vals[4] = {cfg.shake, cfg.roll, cfg.zoom, cfg.dolly};
    for (int i = 0; i < 4; i++) {
        CGFloat y = 152 + i * 56;
        [self.panel addSubview:CSLabel(names[i], CGRectMake(16, y, pw - 32, 20), 14)];
        UISlider *s = [[UISlider alloc] initWithFrame:CGRectMake(16, y + 22, pw - 32, 28)];
        s.minimumValue = 0; s.maximumValue = 1; s.value = vals[i]; s.tag = i;
        [s addTarget:self action:@selector(slChanged:) forControlEvents:UIControlEventValueChanged];
        [self.panel addSubview:s];
    }

    // --- Trạng thái / lỗi ---
    self.status = CSLabel(@"", CGRectMake(16, 380, pw - 32, 110), 11);
    self.status.numberOfLines = 0;
    self.status.textColor = [UIColor colorWithWhite:0.8 alpha:1];
    [self.panel addSubview:self.status];
    [self syncStatus];
}
- (void)syncStatus {
    if (!self.status) return;
    NSString *err;
    @synchronized (CSLock()) { err = gLog.count ? [gLog componentsJoinedByString:@"\n⚠️ "] : nil; }
    NSMutableString *t = [NSMutableString stringWithFormat:@"Camera: %@ • khung đã thay: %lu • ảnh chụp: %lu\n%@",
                        gCaptureSeen ? @"đã nhận" : @"chưa thấy",
                        (unsigned long)gFramesReplaced, (unsigned long)gPhotosReplaced,
                        err ? [@"⚠️ " stringByAppendingString:err] : @"Không có lỗi"];
    NSString *g = CSProcStatusText("com.an.camshake.st.gpu", @"WebKit GPU", [NSBundle.mainBundle.bundleIdentifier containsString:@"safari"]);
    NSString *w = CSProcStatusText("com.an.camshake.st.wc", @"WebContent", NO);
    if (g) [t appendFormat:@"\n%@", g];
    if (w) [t appendFormat:@"\n%@", w];
    self.status.text = t;
}
// Nút luôn hiện ở mọi app; chỉ giữ nó nằm trên cùng và đúng cửa sổ hiện tại
- (void)setActive:(BOOL)a {
    if (!self.button) return;
    if (self.button.hidden) self.button.hidden = NO;
    UIWindow *w = CSKeyWindow();
    if (w && self.button.superview != w) {
        [self.panel removeFromSuperview];
        [self.button removeFromSuperview];
        [w addSubview:self.panel];
        [w addSubview:self.button];
    }
    UIView *sv = self.button.superview;
    if (sv && sv.subviews.lastObject != self.button) {
        [sv bringSubviewToFront:self.panel];
        [sv bringSubviewToFront:self.button];
    }
}
- (void)dragged:(UIPanGestureRecognizer *)g {
    UIView *v = g.view, *sv = v.superview;
    if (!sv) return;
    CGPoint t = [g translationInView:sv];
    CGPoint c = CGPointMake(v.center.x + t.x, v.center.y + t.y);
    c.x = MIN(MAX(c.x, 22), sv.bounds.size.width - 22);
    c.y = MIN(MAX(c.y, 22), sv.bounds.size.height - 22);
    v.center = c;
    [g setTranslation:CGPointZero inView:sv];
    if (g.state == UIGestureRecognizerStateEnded) {
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        [d setFloat:c.x forKey:@"CS_bx"];
        [d setFloat:c.y forKey:@"CS_by"];
    }
}
static char kGesKey;
// Thủ công: giữ 3 ngón tay ~1 giây ở bất kỳ app nào để ép hiện nút 📳
- (void)attachGesture:(UIWindow *)w {
    if (!w || objc_getAssociatedObject(w, &kGesKey)) return;
    UILongPressGestureRecognizer *g = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(forceShow:)];
    g.numberOfTouchesRequired = 3;
    g.minimumPressDuration = 0.8;
    g.cancelsTouchesInView = NO;
    g.delegate = self;
    [w addGestureRecognizer:g];
    objc_setAssociatedObject(w, &kGesKey, g, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (void)forceShow:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    [[CSDriver shared] markCapture];
    CSToast(@"CamShake: đã hiện nút 📳");
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)a shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)b { return YES; }
- (void)toggle {
    self.panel.hidden = !self.panel.hidden;
    [self.button.superview bringSubviewToFront:self.button];
    [self.panel.superview bringSubviewToFront:self.panel];
    if (!self.panel.hidden) [self syncStatus];
}
- (void)swChanged:(UISwitch *)s { cfg.enabled = s.on; CSSave(); }
- (void)useChanged:(UISwitch *)s { cfg.useImage = s.on; CSSave(); }
- (void)slChanged:(UISlider *)s {
    switch (s.tag) {
        case 0: cfg.shake = s.value; break;
        case 1: cfg.roll = s.value; break;
        case 2: cfg.zoom = s.value; break;
        case 3: cfg.dolly = s.value; break;
    }
    CSSave();
}
- (void)syncButtons {
    [self.rotBtn setTitle:[NSString stringWithFormat:@"Xoay %d°", cfg.rot * 90] forState:UIControlStateNormal];
    [self.mirBtn setTitle:cfg.mirror ? @"Lật: Bật" : @"Lật: Tắt" forState:UIControlStateNormal];
}
- (void)syncInfo {
    UIImage *im = gImage;
    if (gHaveImage && im.CGImage)
        self.info.text = [NSString stringWithFormat:@"Ảnh đã chọn: %d×%d", (int)CGImageGetWidth(im.CGImage), (int)CGImageGetHeight(im.CGImage)];
    else
        self.info.text = @"Chưa chọn ảnh - bấm \"Chọn ảnh\"";
    self.uiVer = gImageVersion;
}
- (void)syncIfNeeded { if (self.info && self.uiVer != gImageVersion) [self syncInfo]; }

- (void)btnTapped:(UIButton *)b {
    switch (b.tag) {
        case 0: [self pick]; break;
        case 1: CSClearImage(); [self syncInfo]; CSToast(@"Đã xoá ảnh"); break;
        case 2: cfg.rot = (cfg.rot + 1) & 3; CSSave(); [self syncButtons]; break;
        case 3: cfg.mirror = !cfg.mirror; CSSave(); [self syncButtons]; break;
    }
}
- (void)pick {
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        CSToast(@"Không mở được thư viện ảnh"); return;
    }
    UIViewController *top = CSTopVC();
    if (!top) { CSToast(@"Không mở được thư viện ảnh"); return; }
    UIImagePickerController *p = [UIImagePickerController new];
    p.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    p.mediaTypes = @[@"public.image"];
    p.delegate = self;
    self.panel.hidden = YES;
    [top presentViewController:p animated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)p didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey, id> *)info {
    UIImage *img = info[UIImagePickerControllerOriginalImage];
    [p dismissViewControllerAnimated:YES completion:nil];
    if (!img) { CSNote(@"pick", @"Không đọc được ảnh đã chọn", YES); return; }
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        CSSetImage(img);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self syncInfo];
            CSToast(@"Đã nạp ảnh - dùng cho mọi app camera");
        });
    });
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)p {
    [p dismissViewControllerAnimated:YES completion:nil];
}
@end

#pragma mark - Hooks (Objective-C runtime, không cần Substrate)

typedef id (*CSInitIMP)(id, SEL);
typedef id (*CSInitSessIMP)(id, SEL, id);
static CSInitIMP origInit;
static CSInitSessIMP origInitSession, origInitNoConn;

static id hkInit(id self, SEL _cmd) {
    id s = origInit(self, _cmd);
    if (s) [[CSDriver shared] add:s];
    return s;
}
static id hkInitSession(id self, SEL _cmd, id session) {
    id s = origInitSession(self, _cmd, session);
    if (s) [[CSDriver shared] add:s];
    return s;
}
static id hkInitNoConn(id self, SEL _cmd, id session) {
    id s = origInitNoConn(self, _cmd, session);
    if (s) [[CSDriver shared] add:s];
    return s;
}

static BOOL CSHook(Class cls, SEL sel, IMP hk, IMP *orig) {
    if (!cls || !sel) return NO;
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return NO;
    *orig = method_getImplementation(m);
    // replaceMethod trên chính class: không đụng tới superclass
    class_replaceMethod(cls, sel, hk, method_getTypeEncoding(m));
    return YES;
}
static NSMutableArray *gHookFail;
// critical = hook bắt buộc để tính năng chạy; thiếu thì báo lỗi
static void CSHookReq(BOOL critical, NSString *name, Class cls, SEL sel, IMP hk, IMP *orig) {
    if (CSHook(cls, sel, hk, orig)) return;
    NSString *m = [NSString stringWithFormat:@"không hook được %@", name];
    NSLog(@"[CamShake] %@", m);
    if (critical) {
        if (!gHookFail) gHookFail = [NSMutableArray array];
        [gHookFail addObject:name];
        CSNote([@"hook:" stringByAppendingString:name], [@"Lỗi: " stringByAppendingString:m], NO);
    }
}

#pragma mark - Hook luồng khung hình (AVCaptureVideoDataOutput)

static NSMutableDictionary<NSValue *, NSValue *> *gDelegOrig; // Class -> IMP gốc

static IMP CSDelegOrig(id obj) {
    @synchronized (CSLock()) {
        for (Class c = object_getClass(obj); c; c = class_getSuperclass(c)) {
            NSValue *v = gDelegOrig[[NSValue valueWithPointer:(__bridge void *)c]];
            if (v) return (IMP)[v pointerValue];
        }
    }
    return NULL;
}

static CVPixelBufferRef gFxScratch; static size_t gFxW, gFxH; static OSType gFxF;

// Rung / xoay / zoom / đẩy máy áp thẳng lên pixel buffer (dùng cho camera web và app tự vẽ camera)
static void CSApplyFx(CVPixelBufferRef pb) {
    size_t W = CVPixelBufferGetWidth(pb), H = CVPixelBufferGetHeight(pb);
    OSType f = CVPixelBufferGetPixelFormatType(pb);
    CGFloat minDim = MIN(W, H);
    if (minDim < 16) return;
    @synchronized (CSLock()) {
        if (!gFxScratch || gFxW != W || gFxH != H || gFxF != f) {
            if (gFxScratch) { CFRelease(gFxScratch); gFxScratch = NULL; }
            NSDictionary *attrs = @{ (__bridge id)kCVPixelBufferIOSurfacePropertiesKey: @{} };
            CVPixelBufferRef t = NULL;
            if (CVPixelBufferCreate(kCFAllocatorDefault, W, H, f, (__bridge CFDictionaryRef)attrs, &t) != kCVReturnSuccess || !t) {
                CSNote(@"fxpb", [NSString stringWithFormat:@"Không tạo được bộ đệm hiệu ứng %@ (%zux%zu)", CSFourCC(f), W, H], YES);
                return;
            }
            gFxScratch = t; gFxW = W; gFxH = H; gFxF = f;
        }
        double t = CACurrentMediaTime();
        CGFloat k = minDim / 390.0;                       // quy đổi "pt trên màn hình điện thoại" -> pixel khung hình
        CGFloat sMax = 12.0 * cfg.shake * k;
        CGFloat dx = sMax * (sin(t * 7.3) + 0.5 * sin(t * 13.1 + 1.7)) / 1.5;
        CGFloat dy = sMax * (sin(t * 6.1 + 0.9) + 0.5 * sin(t * 11.3 + 2.4)) / 1.5;
        CGFloat rollMax = 3.0 * cfg.roll * M_PI / 180.0;
        CGFloat rollRad = rollMax * (sin(t * 5.1) + 0.4 * sin(t * 11.7 + 0.6)) / 1.4;
        CGFloat margin = 1.0 + 2.0 * sMax / minDim + rollMax * (MAX(W, H) / minDim) + 0.01;
        CGFloat zoom = 1.0 + 0.5 * cfg.zoom;
        CGFloat push = 1.0 + 0.24 * cfg.dolly * (0.5 + 0.5 * sin(t * 2.5));
        CGFloat sc = margin * zoom * push;
        CGFloat cx = W / 2.0, cy = H / 2.0;
        CGAffineTransform tr = CGAffineTransformMakeTranslation(cx + dx, cy + dy);
        tr = CGAffineTransformRotate(tr, rollRad);
        tr = CGAffineTransformScale(tr, sc, sc);
        tr = CGAffineTransformTranslate(tr, -cx, -cy);
        CIImage *src = [CIImage imageWithCVPixelBuffer:pb];
        if (!src) { CSNote(@"fxci", @"Không đọc được khung hình để áp hiệu ứng", YES); return; }
        CIImage *out = [[src imageByApplyingTransform:tr] imageByCroppingToRect:CGRectMake(0, 0, W, H)];
        [CSCIContext() render:out toCVPixelBuffer:gFxScratch bounds:CGRectMake(0, 0, W, H) colorSpace:CSRGB()];
        CSCopyPB(gFxScratch, pb);
    }
}

static CVPixelBufferRef gMkScratch; static size_t gMkW, gMkH; static OSType gMkF;
static void CSDrawMark(CVPixelBufferRef pb) {
    size_t W = CVPixelBufferGetWidth(pb), H = CVPixelBufferGetHeight(pb);
    OSType f = CVPixelBufferGetPixelFormatType(pb);
    if (MIN(W, H) < 16) return;
    @synchronized (CSLock()) {
        if (!gMkScratch || gMkW != W || gMkH != H || gMkF != f) {
            if (gMkScratch) { CFRelease(gMkScratch); gMkScratch = NULL; }
            NSDictionary *attrs = @{ (__bridge id)kCVPixelBufferIOSurfacePropertiesKey: @{} };
            CVPixelBufferRef nb = NULL;
            if (CVPixelBufferCreate(kCFAllocatorDefault, W, H, f, (__bridge CFDictionaryRef)attrs, &nb) != kCVReturnSuccess || !nb) return;
            gMkScratch = nb; gMkW = W; gMkH = H; gMkF = f;
        }
        BOOL gpu = [gProcKind isEqualToString:@"gpu"];
        CIColor *c = gpu ? [CIColor colorWithRed:1 green:0 blue:0] : [CIColor colorWithRed:0 green:0.35 blue:1];
        CGFloat sq = MIN(W, H) * 0.14;
        CIImage *src = [CIImage imageWithCVPixelBuffer:pb];
        CIImage *box = [[CIImage imageWithColor:c] imageByCroppingToRect:CGRectMake(0, 0, sq, sq)];
        CIImage *out = [box imageByCompositingOverImage:src];
        [CSCIContext() render:out toCVPixelBuffer:gMkScratch bounds:CGRectMake(0, 0, W, H) colorSpace:CSRGB()];
        CSCopyPB(gMkScratch, pb);
    }
}

static void CSProcessFrame(id output, CMSampleBufferRef sb) {
    BOOL img = CSActive(), fx = CSFxWanted();
    BOOL mark = (CS_WEB_MARK && gHeadless);
    if (!sb || (!img && !fx && !mark)) return;
    static Class vdo; static dispatch_once_t once;
    dispatch_once(&once, ^{ vdo = NSClassFromString(@"AVCaptureVideoDataOutput"); });
    if (!vdo || ![output isKindOfClass:vdo]) return;
    CVPixelBufferRef pb = CMSampleBufferGetImageBuffer(sb);
    if (!pb) { CSNote(@"nopb", @"Khung hình camera dạng nén (không có pixel buffer) - không thay được", YES); return; }
    if (img) {
        size_t W = CVPixelBufferGetWidth(pb), H = CVPixelBufferGetHeight(pb);
        // Buffer camera thường nằm ngang (landscape) -> xoay ảnh 90° để hiển thị thẳng đứng
        int q = ((W > H ? 1 : 0) + cfg.rot) & 3;
        CVPixelBufferRef t = CSTemplate(pb, q, cfg.mirror);
        if (t) { CSCopyPB(t, pb); CFRelease(t); gFramesReplaced++; }
    }
    if (fx) { CSApplyFx(pb); if (!img) gFramesReplaced++; }
    if (mark) CSDrawMark(pb);
}

static void hkDidOutput(id self, SEL _cmd, id output, CMSampleBufferRef sb, id conn) {
    CSProcessFrame(output, sb);
    IMP o = CSDelegOrig(self);
    if (o) ((void (*)(id, SEL, id, CMSampleBufferRef, id))o)(self, _cmd, output, sb, conn);
}

static void CSHookDelegateClass(Class cls) {
    SEL sel = @selector(captureOutput:didOutputSampleBuffer:fromConnection:);
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return;
    IMP cur = method_getImplementation(m);
    if (cur == (IMP)hkDidOutput) return; // đã hook (kể cả ở superclass)
    NSValue *key = [NSValue valueWithPointer:(__bridge void *)cls];
    @synchronized (CSLock()) {
        if (!gDelegOrig) gDelegOrig = [NSMutableDictionary dictionary];
        if (gDelegOrig[key]) return;
        gDelegOrig[key] = [NSValue valueWithPointer:(void *)cur];
    }
    class_replaceMethod(cls, sel, (IMP)hkDidOutput, method_getTypeEncoding(m));
}

typedef void (*CSSetDelegIMP)(id, SEL, id, dispatch_queue_t);
static CSSetDelegIMP origSetDeleg;
static void hkSetDeleg(id self, SEL _cmd, id d, dispatch_queue_t q) {
    if (d) {
        CSHookDelegateClass(object_getClass(d));
        [[CSDriver shared] markCapture];
    }
    origSetDeleg(self, _cmd, d, q);
}

#pragma mark - Hook ảnh chụp (AVCapturePhotoOutput / AVCaptureStillImageOutput)

static char kPhotoDataKey, kPhotoPBKey, kPhotoCGKey;

static int CSPhotoOrientation(id photo) {
    NSDictionary *md = [(AVCapturePhoto *)photo metadata];
    return [md[(__bridge NSString *)kCGImagePropertyOrientation] intValue];
}
// Ảnh gốc (raw) = ảnh thẳng đứng xoay ngược chiều kim đồng hồ q lần 90° (EXIF 6 -> 1, 8 -> 3, 3 -> 2)
static int CSQuarterForOrientation(int o) {
    switch (o) {
        case 6: case 5: return 1;
        case 3: case 4: return 2;
        case 8: case 7: return 3;
        default: return 0;
    }
}

static NSData *CSPhotoData(id photo, NSData *d) {
    if (!d || !CSActive()) return d;
    NSData *c = objc_getAssociatedObject(photo, &kPhotoDataKey);
    if (c) return c;
    NSData *n = CSReplaceJPEG(d);
    if (n != d) { gPhotosReplaced++; objc_setAssociatedObject(photo, &kPhotoDataKey, n, OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    return n;
}

static NSData *(*origFileData)(id, SEL);
static NSData *hkFileData(id self, SEL _cmd) { return CSPhotoData(self, origFileData(self, _cmd)); }

static NSData *(*origFileDataCust)(id, SEL, id);
static NSData *hkFileDataCust(id self, SEL _cmd, id cust) { return CSPhotoData(self, origFileDataCust(self, _cmd, cust)); }

static CVPixelBufferRef (*origPhotoPB)(id, SEL);
static CVPixelBufferRef hkPhotoPB(id self, SEL _cmd) {
    CVPixelBufferRef pb = origPhotoPB(self, _cmd);
    if (pb && CSActive() && !objc_getAssociatedObject(self, &kPhotoPBKey)) {
        CVPixelBufferRef t = CSTemplate(pb, CSQuarterForOrientation(CSPhotoOrientation(self)), cfg.mirror);
        if (t) { CSCopyPB(t, pb); CFRelease(t); gPhotosReplaced++; }
        objc_setAssociatedObject(self, &kPhotoPBKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return pb;
}

static CGImageRef (*origPhotoCG)(id, SEL);
static CGImageRef hkPhotoCG(id self, SEL _cmd) {
    CGImageRef orig = origPhotoCG(self, _cmd);
    if (!orig || !CSActive()) return orig;
    UIImage *c = objc_getAssociatedObject(self, &kPhotoCGKey);
    if (!c) {
        size_t w = CGImageGetWidth(orig), h = CGImageGetHeight(orig);
        if (w * h > 50000000UL) return orig;
        CGImageRef n = CSCreateRendered(w, h, CSQuarterForOrientation(CSPhotoOrientation(self)), cfg.mirror);
        if (!n) return orig;
        c = [UIImage imageWithCGImage:n];
        CGImageRelease(n);
        objc_setAssociatedObject(self, &kPhotoCGKey, c, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        gPhotosReplaced++;
    }
    return c.CGImage;
}

// +[AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:]  (API cũ)
static NSData *(*origStillJPEG)(id, SEL, CMSampleBufferRef);
static NSData *hkStillJPEG(id self, SEL _cmd, CMSampleBufferRef sb) {
    return CSReplaceJPEG(origStillJPEG(self, _cmd, sb));
}
// +[AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:previewPhotoSampleBuffer:]  (API cũ)
static NSData *(*origPhotoJPEG)(id, SEL, CMSampleBufferRef, CMSampleBufferRef);
static NSData *hkPhotoJPEG(id self, SEL _cmd, CMSampleBufferRef a, CMSampleBufferRef b) {
    return CSReplaceJPEG(origPhotoJPEG(self, _cmd, a, b));
}

// Mọi app chạy AVCaptureSession đều được coi là app camera (kể cả không có preview layer)
static void (*origStartRunning)(id, SEL);
static void hkStartRunning(id self, SEL _cmd) {
    origStartRunning(self, _cmd);
    [[CSDriver shared] markCapture];
}

static void CSToast(NSString *text) {
    UIWindow *w = CSKeyWindow();
    if (!w) return;
    UILabel *l = [UILabel new];
    l.text = text;
    l.numberOfLines = 0;
    l.textColor = UIColor.whiteColor;
    l.font = [UIFont boldSystemFontOfSize:13];
    l.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
    l.layer.cornerRadius = 12;
    l.clipsToBounds = YES;
    l.textAlignment = NSTextAlignmentCenter;
    CGFloat maxW = w.bounds.size.width - 40;
    CGSize sz = [l sizeThatFits:CGSizeMake(maxW - 20, 400)];
    CGFloat bw = MIN(maxW, sz.width + 20), bh = sz.height + 14;
    l.frame = CGRectMake((w.bounds.size.width - bw) / 2, 60, bw, bh);
    [w addSubview:l];
    [UIView animateWithDuration:0.4 delay:1.8 + 0.04 * text.length options:0 animations:^{ l.alpha = 0; }
                     completion:^(BOOL f) { [l removeFromSuperview]; }];
}

static BOOL gToasted = NO;
static void CSKick(void) {
    [[CSDriver shared] startScanning];
    [[CSUI shared] install];
    if (gToasted || ![CSUI shared].button) return;   // chỉ báo "đã nạp" khi nút thật sự đã gắn vào cửa sổ
    gToasted = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (gHookFail.count)
            CSToast([NSString stringWithFormat:@"⚠️ CamShake nạp nhưng lỗi hook:\n%@", [gHookFail componentsJoinedByString:@"\n"]]);
        else
            CSToast(@"CamShake đã nạp");
    });
}

__attribute__((constructor))
static void CSMain(void) {
    @autoreleasepool {
        // Nạp vào mọi app UIKit; bỏ qua SpringBoard. Nút chỉ hiện khi app có camera.
        NSString *bid = NSBundle.mainBundle.bundleIdentifier;
        NSString *exe = NSProcessInfo.processInfo.processName;
        BOOL isApp = [NSBundle.mainBundle.bundlePath hasSuffix:@".app"];
        BOOL isWK = [exe isEqualToString:@"com.apple.WebKit.GPU"] || [exe isEqualToString:@"com.apple.WebKit.WebContent"];
        if (!isApp && !isWK) return;               // bỏ qua daemon / process hệ thống khác
        if (!isWK && (!bid || [bid isEqualToString:@"com.apple.springboard"])) return;
        gHeadless = isWK;
        if (isWK) gProcKind = [exe isEqualToString:@"com.apple.WebKit.GPU"] ? @"gpu" : @"wc";

        CSLoad();
        if (!isWK) CSSaveWebPrefs();   // trình duyệt: đẩy thông số hiện tại sang process WebKit

        Class cls = NSClassFromString(@"AVCaptureVideoPreviewLayer");
        CSHookReq(YES, @"AVCaptureVideoPreviewLayer.init", cls, @selector(init), (IMP)hkInit, (IMP *)&origInit);
        CSHookReq(NO, @"AVCaptureVideoPreviewLayer.initWithSession:", cls, @selector(initWithSession:), (IMP)hkInitSession, (IMP *)&origInitSession);
        CSHookReq(NO, @"AVCaptureVideoPreviewLayer.initWithSessionWithNoConnection:", cls, NSSelectorFromString(@"initWithSessionWithNoConnection:"), (IMP)hkInitNoConn, (IMP *)&origInitNoConn);
        CSHookReq(YES, @"AVCaptureSession.startRunning", NSClassFromString(@"AVCaptureSession"), @selector(startRunning), (IMP)hkStartRunning, (IMP *)&origStartRunning);
        CSHookReq(YES, @"AVCaptureVideoDataOutput.setSampleBufferDelegate:queue:", NSClassFromString(@"AVCaptureVideoDataOutput"), @selector(setSampleBufferDelegate:queue:), (IMP)hkSetDeleg, (IMP *)&origSetDeleg);

        Class photo = NSClassFromString(@"AVCapturePhoto");
        CSHookReq(YES, @"AVCapturePhoto.fileDataRepresentation", photo, @selector(fileDataRepresentation), (IMP)hkFileData, (IMP *)&origFileData);
        CSHookReq(NO, @"AVCapturePhoto.fileDataRepresentationWithCustomizer:", photo, NSSelectorFromString(@"fileDataRepresentationWithCustomizer:"), (IMP)hkFileDataCust, (IMP *)&origFileDataCust);
        CSHookReq(NO, @"AVCapturePhoto.pixelBuffer", photo, @selector(pixelBuffer), (IMP)hkPhotoPB, (IMP *)&origPhotoPB);
        SEL cgSel = NSSelectorFromString(@"CGImageRepresentation");
        if (photo && !class_getInstanceMethod(photo, cgSel)) cgSel = NSSelectorFromString(@"cgImageRepresentation");
        CSHookReq(NO, @"AVCapturePhoto.CGImageRepresentation", photo, cgSel, (IMP)hkPhotoCG, (IMP *)&origPhotoCG);
        Class still = NSClassFromString(@"AVCaptureStillImageOutput");
        CSHookReq(NO, @"AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation:", still ? object_getClass(still) : Nil, NSSelectorFromString(@"jpegStillImageNSDataRepresentation:"), (IMP)hkStillJPEG, (IMP *)&origStillJPEG);
        Class pout = NSClassFromString(@"AVCapturePhotoOutput");
        CSHookReq(NO, @"AVCapturePhotoOutput.JPEGPhotoDataRepresentation", pout ? object_getClass(pout) : Nil, NSSelectorFromString(@"JPEGPhotoDataRepresentationForJPEGSampleBuffer:previewPhotoSampleBuffer:"), (IMP)hkPhotoJPEG, (IMP *)&origPhotoJPEG);

        NSLog(@"[CamShake] loaded in %@", bid);
        if (isWK) dispatch_async(dispatch_get_main_queue(), ^{ [[CSDriver shared] startHeadless]; });
        if (!isWK) {
            // Khởi động chắc chắn: không chỉ dựa vào DidBecomeActive (app nạp muộn / app dùng scene / game tự quản lý cửa sổ)
            NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
            for (NSNotificationName nm in @[UIApplicationDidBecomeActiveNotification,
                                            UIWindowDidBecomeVisibleNotification,
                                            UIWindowDidBecomeKeyNotification,
                                            UISceneDidActivateNotification]) {
                [nc addObserverForName:nm object:nil queue:NSOperationQueue.mainQueue
                            usingBlock:^(NSNotification *n) { CSKick(); }];
            }
            for (NSNumber *d in @[@1.5, @4.0, @10.0])   // dự phòng nếu không có thông báo nào bắn
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(d.doubleValue * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{ CSKick(); });
        }
    }
}
